#!/bin/bash

NL=$'\n'
version=$1
current_version=false
commit_release=""
while IFS= read -r line; do
  if [[ $line == "## "* ]] ;
  then
    line_version="${line:3}"
    if [ $line_version == $version ]; then
      current_version=true
      echo $current_version
    else
      current_version=false
    fi
  elif $current_version; then
    commit_release="$commit_release$line${NL}"
  fi
done < RELEASE_NOTES.md

echo "$commit_release" > release_description.txt
