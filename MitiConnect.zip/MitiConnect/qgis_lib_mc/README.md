# qgis-lib-mc
PyQGIS utilities library to develop plugins or scripts
