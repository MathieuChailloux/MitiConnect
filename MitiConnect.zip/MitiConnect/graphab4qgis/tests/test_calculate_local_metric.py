__author__ = 'gaspard.quentin1905@gmail.com'
__date__ = '2023-06-26'
__copyright__ = 'Copyright 2023, Laboratoire ThéMA'

import unittest

from .graphab_test_case import GraphabTestCase
from ..processing.CalculateLocalMetric import CalculateLocalMetric
from qgis.core import QgsProcessingContext, QgsProcessingFeedback


class TestCalculateLocalMetric(GraphabTestCase):

    @unittest.skip('Test not implemented yet')
    def test_processing_algo(self):
        
        # TODO: test with relevant config parameters
        config = { 
            'INPUT': None, # xml file that represent the Graphab project
            'GRAPHNAME': "",
            'METRICSNAME': 0,
            'DPARAMETER': 1000.0,
            'PPARAMETER': 0,
            'DISTUNIT': 0
        }

        # init algo, context & feedback
        alg = CalculateLocalMetric()
        ctx = QgsProcessingContext()
        feedback = QgsProcessingFeedback()

        alg.initAlgorithm()

        # process algo & get output
        output: dict[str, any] = alg.processAlgorithm(config, ctx, feedback)

        # post process
        post_output = alg.postProcessAlgorithm(ctx, feedback)

        # make tests on the output & post_output 
        # TODO: replace with relevant tests
        self.assertIsNotNone(output)
        self.assertIsNotNone(post_output) 

if __name__ == '__main__':
    suite: unittest.TestSuite = unittest.makeSuite(TestCalculateLocalMetric)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)