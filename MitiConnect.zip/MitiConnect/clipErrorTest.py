paramsOK = {
    'ALPHA_BAND' : False,
    'CREATION_OPTIONS' : None,
    'CROP_TO_CUTLINE' : True,
    'DATA_TYPE' : 0,
    'EXTRA' : '',
    'INPUT' : 'F:/IRSTEA/ERC/Tutoriel/Source/PollLum/radiance-nocturne-luojia1-2018-d74/radiance_nocturne_LuoJia1_2018_D74.tif',
    'KEEP_RESOLUTION' : False,
    'MASK' : 'F:/IRSTEA/ERC/Tuto/Source/DATA_OS/Emprise_large.shp',
    'MULTITHREADING' : False,
    'NODATA' : 0,
    'OUTPUT' : 'C:/Users/mchailloux/AppData/Local/Temp/test.tif',
    'SET_RESOLUTION' : True, 
    'SOURCE_CRS' : None,
    'TARGET_CRS' : None,
    'TARGET_EXTENT' : None,
    'X_RESOLUTION' : 25,
    'Y_RESOLUTION' : 25 }
paramsTmp = {
    'ALPHA_BAND' : False,
    'CROP_TO_CUTLINE' : True,
    'DATA_TYPE' : 0,
    'INPUT' : 'F:/IRSTEA/ERC/Tutoriel/Source/PollLum/radiance-nocturne-luojia1-2018-d74/radiance_nocturne_LuoJia1_2018_D74.tif',
    'KEEP_RESOLUTION' : False,
    'MASK' : 'F:/IRSTEA/ERC/Tuto/Source/DATA_OS/Emprise_large.shp',
    'NODATA' : 0,
    'OUTPUT' : 'C:/Users/mchailloux/AppData/Local/Temp/test.tif',
    'SET_RESOLUTION' : True, 
    'X_RESOLUTION' : 25,
    'Y_RESOLUTION' : 25 }
    
paramsKO = {'ALPHA_BAND': False,
    'CROP_TO_CUTLINE': True,
    'DATA_TYPE': 0,
    'INPUT': 'F:\\IRSTEA\\ERC\\Tutoriel\\Source\\PollLum\\radiance-nocturne-luojia1-2018-d74\\radiance_nocturne_LuoJia1_2018_D74.tif',
    'KEEP_RESOLUTION': False,
    'MASK': 'F:\\IRSTEA\\ERC\\Tuto\\Source\\DATA_OS\\Emprise_large.shp',
    'NODATA': 0,
    'OPTIONS': '',
    'OUTPUT': 'C:/Users/mchailloux/pollLum3.tif',
    'SET_RESOLUTION': True,
    'X_RESOLUTION': 25.0,
    'Y_RESOLUTION': 25.0}
    
import processing
from qgis.core import QgsProcessingFeedback, QgsProcessingContext

class MyFeedback(QgsProcessingFeedback):

    def pushInfo(self, info):
        print("INFO :", info)
        super().pushInfo(info)

    def pushCommandInfo(self, info):
        print("COMMAND :", info)
        super().pushCommandInfo(info)

    def pushDebugInfo(self, info):
        print("DEBUG :", info)
        super().pushDebugInfo(info)

    def reportError(self, error, fatalError=False):
        print("ERROR :", error)
        super().reportError(error, fatalError)
        
def no_post_process(alg, context, feedback):
    pass
context = QgsProcessingContext()

processing.run('gdal:cliprasterbymasklayer',
    paramsKO,onFinish=no_post_process,
    context=context,feedback=MyFeedback())
