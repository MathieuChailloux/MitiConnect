# import qgis libs so that ve set the correct sip api version
import qgis   # pylint: disable=W0611  # NOQA

import sys
import os

sys.path.insert(1, os.path.join(sys.path[0], '..'))
__package__ = None
