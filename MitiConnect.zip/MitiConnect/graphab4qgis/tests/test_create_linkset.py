
__author__ = 'gaspard.quentin1905@gmail.com'
__date__ = '2023-06-26'
__copyright__ = 'Copyright 2023, Laboratoire ThéMA'

import unittest

from .graphab_test_case import GraphabTestCase
from ..processing.CreateLinkset import CreateLinkset
from qgis.core import QgsProcessingContext, QgsProcessingFeedback

class TestCreateLinkset(GraphabTestCase):
    
    @unittest.skip('Test not implemented yet')
    def test_processing_algo(self):
        
        # TODO: make tests with relevant config parameters
        config = {
            'INPUT': None,
            'NAME': None,
            'TYPE': None,
            'CODE': None,
            'EXTCOST': None
        }

        #init algo, context & feedback
        alg = CreateLinkset()
        ctx = QgsProcessingContext()
        feedback = QgsProcessingFeedback()

        alg.initAlgorithm(config)

        # process algo & get output
        output: dict[str, any] = alg.processAlgorithm(config, ctx, feedback)
        post_output: dict = alg.postProcessAlgorithm(ctx, feedback)

        # make tests on output & post_output
        # TODO: make relevant tests
        self.assertIsNotNone(output)
        self.assertIsNotNone(post_output)

if __name__ == '__main__':
    suite: unittest.TestSuite = unittest.makeSuite(TestCreateLinkset)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite) 