<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="fr_FR" sourcelanguage="">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../ui_files/calculate_metrics_dialog.ui" line="23"/>
        <source>Calculate Metrics</source>
        <translation>Calcul de métriques</translation>
    </message>
    <message>
        <location filename="../ui_files/calculate_metrics_dialog.ui" line="23"/>
        <source>Convert distance</source>
        <translation type="obsolete">Conversion distance</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="68"/>
        <source>Project</source>
        <translation>Projet</translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="73"/>
        <source>Graph</source>
        <translation>Graphe</translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="42"/>
        <source>Metric</source>
        <translation>Métrique</translation>
    </message>
    <message>
        <location filename="../ui_files/calculate_metrics_dialog.ui" line="92"/>
        <source>Probability</source>
        <translation>Probabilité</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="23"/>
        <source>Distance</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../ui_files/create_graph_dialog.ui" line="23"/>
        <source>Create Graph</source>
        <translation>Créer un Graphe</translation>
    </message>
    <message>
        <location filename="../ui_files/create_graph_dialog.ui" line="49"/>
        <source>Graph name</source>
        <translation>Nom du Graphe</translation>
    </message>
    <message>
        <location filename="../ui_files/create_graph_dialog.ui" line="29"/>
        <source>Pruning</source>
        <translation>Élagage</translation>
    </message>
    <message>
        <location filename="../ui_files/create_graph_dialog.ui" line="56"/>
        <source>Linkset</source>
        <translation>Jeu de liens</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="17"/>
        <source>Create Linkset</source>
        <translation>Créer un jeu de liens</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="29"/>
        <source>Euclidean</source>
        <translation>Euclidien</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="42"/>
        <source>Cost</source>
        <translation>Coût</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="55"/>
        <source>External cost</source>
        <translation>Coût externe</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="102"/>
        <source>Linkset name</source>
        <translation>Nom du jeu de liens</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="140"/>
        <source>Code</source>
        <translation>Code</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="151"/>
        <source>Value</source>
        <translation>Valeur</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="95"/>
        <source>External cost file</source>
        <translation>Fichier de coût externe</translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="66"/>
        <source>Color ramp</source>
        <translation>Rampe de couleur</translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="52"/>
        <source>Minimum scale</source>
        <translation>Taille minimale</translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="59"/>
        <source>Maximum scale</source>
        <translation>Taille maximale</translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="32"/>
        <source>Circle size based on the &apos;Capacity&apos;</source>
        <translation>Taille des cercles basée sur la &apos;Capacité&apos;</translation>
    </message>
    <message>
        <location filename="../ui_files/create_linkset_dialog.ui" line="88"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui_files/graph_symbology_dialog.ui" line="23"/>
        <source>Display metric</source>
        <translation>Afficher une métrique</translation>
    </message>
    <message>
        <location filename="../ui_files/corridor_dialog.ui" line="23"/>
        <source>Corridor</source>
        <translation>Corridor</translation>
    </message>
    <message>
        <location filename="../ui_files/corridor_dialog.ui" line="69"/>
        <source>Distance max</source>
        <translation>Distance max</translation>
    </message>
</context>
<context>
    <name>OsRasterDialogBase</name>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="26"/>
        <source>Create landscape map</source>
        <translation>Créer une carte d&apos;occupation du sol</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="44"/>
        <source>Start</source>
        <translation>Éxécuter</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="51"/>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="62"/>
        <source>Import save</source>
        <translation>Importer une sauvegarde</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="65"/>
        <source>Import</source>
        <translation>Importer</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="85"/>
        <source>Export save</source>
        <translation>Exporter une sauvegarde</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="88"/>
        <source>Export</source>
        <translation>Exporter</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="121"/>
        <source>Clear all</source>
        <translation>Tout effacer</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="168"/>
        <source>1 - Layers</source>
        <translation>1 - Couches</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="253"/>
        <source>Rasters</source>
        <translation>Rasters</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="260"/>
        <source>Add raster</source>
        <translation>Ajouter raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="286"/>
        <source>Edit raster encoding</source>
        <translation>Modifier encodage raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="289"/>
        <source>Edit</source>
        <translation>Modifier</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="312"/>
        <source>Remove raster</source>
        <translation>Supprimer raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="502"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="815"/>
        <source>File</source>
        <translation>Fichier</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="400"/>
        <source>New encoding</source>
        <translation>Nouvel encodage</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="414"/>
        <source>Vectors</source>
        <translation>Vecteurs</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="421"/>
        <source>Add vector</source>
        <translation>Ajouter vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="424"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="447"/>
        <source>Edit vector encoding</source>
        <translation>Modifier encodage vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="473"/>
        <source>Edit vector</source>
        <translation>Modifier vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="499"/>
        <source>Remove vector</source>
        <translation>Supprimer vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="578"/>
        <source>Burn-in</source>
        <translation>Valeur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="583"/>
        <source>Touch</source>
        <translation>Touchent</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="588"/>
        <source>Buffer</source>
        <translation>Tampon</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="671"/>
        <source>2 - Merge</source>
        <translation>2 - Fusion</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="820"/>
        <source>Original value</source>
        <translation>Valeur originale</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="825"/>
        <source>Final value</source>
        <translation>Valeur finale</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="834"/>
        <source>3 - Output</source>
        <translation>3 - Sortie</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="847"/>
        <source>Vertical/Horizontal resolution :</source>
        <translation>Résolution verticale/horizontale :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="854"/>
        <source>10.00000</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="865"/>
        <source>Nodata value [optional] :</source>
        <translation>Valeur de nodata [optionnelle] :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="883"/>
        <source>Output extent (xmin, xmax, ymin, ymax)</source>
        <translation>Étendue de sortie (xmin, xmax, ymin, ymax)</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="893"/>
        <source>South</source>
        <translation>Sud</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="954"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="911"/>
        <source>East</source>
        <translation>Est</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="929"/>
        <source>West</source>
        <translation>Ouest</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="947"/>
        <source>North</source>
        <translation>Nord</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="966"/>
        <source>Calculate from Layer</source>
        <translation>Calculer depuis une couche</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="976"/>
        <source>Number of pixels :</source>
        <translation>Nombre de pixels :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="989"/>
        <source>No Data</source>
        <translation>Pas de données</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="1025"/>
        <source>CRS :</source>
        <translation>SRC :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="1035"/>
        <source>Output file :</source>
        <translation>Fichier de sortie :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="1045"/>
        <source>Select an output file</source>
        <translation>Sélectonnez un ficher de sortie</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="1048"/>
        <source>*.tif</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_dialog_base.ui" line="1077"/>
        <source>Log</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>Rasterize</name>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="71"/>
        <source>Pixels</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="72"/>
        <source>Georeferenced units</source>
        <translation>Unités géoréférencées</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="74"/>
        <source>Input layer</source>
        <translation>Couche source</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="76"/>
        <source>Field to use for a burn-in value</source>
        <translation>Champ à utiliser pour la valeur fixe à créer</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="82"/>
        <source>A fixed value to burn</source>
        <translation>Une valeur fixe à graver</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="87"/>
        <source>Output raster size units</source>
        <translation>Unité du raster résultat</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="90"/>
        <source>Width/Horizontal resolution</source>
        <translation>Largeur/Résolution horizontale</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="95"/>
        <source>Height/Vertical resolution</source>
        <translation>Hauteur/résolution verticale</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="100"/>
        <source>Output extent</source>
        <translation>Emprise du résultat</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="102"/>
        <source>Assign a specified nodata value to output bands</source>
        <translation>Affecter une valeur nulle spécifiée aux bandes de sortie</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="108"/>
        <source>Additional creation options</source>
        <translation>Options de création supplémentaires</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="118"/>
        <source>Output data type</source>
        <translation>Type de données en sortie</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="126"/>
        <source>All pixels touch</source>
        <translation>Tous les pixels touchent</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="132"/>
        <source>Pre-initialize the output image with value</source>
        <translation>Pré-initialiser l&apos;image de sortie avec la valeur</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="139"/>
        <source>Invert rasterization</source>
        <translation>Inverser la rasterisation</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="145"/>
        <source>Rasterized</source>
        <translation>Rasterisé</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="152"/>
        <source>Rasterize (vector to raster)</source>
        <translation>Rasteriser (vecteur en raster)</translation>
    </message>
    <message>
        <location filename="../processing/OsRaster/Rasterize.py" line="155"/>
        <source>Vector conversion</source>
        <translation>Vecteur conversion</translation>
    </message>
</context>
<context>
    <name>SelectOptionRasterDialog</name>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_raster_window.ui" line="26"/>
        <source>Select options for raster</source>
        <translation>Sélection d&apos;options pour raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_raster_window.ui" line="54"/>
        <source>Select a raster file :</source>
        <translation>Sélectionnez un fichier raster :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_raster_window.ui" line="70"/>
        <source>Select a raster file</source>
        <translation>Sélectionnez un fichier raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_raster_window.ui" line="89"/>
        <source>Encoding of values :</source>
        <translation>Encodage des valeurs :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_raster_window.ui" line="118"/>
        <source>Code</source>
        <translation>Code</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_raster_window.ui" line="123"/>
        <source>Final code</source>
        <translation>Code final</translation>
    </message>
</context>
<context>
    <name>SelectOptionVectorDialog</name>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="35"/>
        <source>Select options for vector</source>
        <translation>Sélection d&apos;options pour vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="75"/>
        <source>Select a vector file</source>
        <translation>Sélectionnez un fichier vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="91"/>
        <source>Select a vector file :</source>
        <translation>Sélectionnez un fichier vecteur :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="107"/>
        <source>Burn-in value</source>
        <translation>Valeur de rasterisation</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="119"/>
        <source>Type of value :</source>
        <translation>Type de valeur :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="135"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="151"/>
        <source>Select a field :</source>
        <translation type="obsolete">Sélectionnez un champ :</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="167"/>
        <source>Fixed value</source>
        <translation>Valeur fixe</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="148"/>
        <source>Field</source>
        <translation>Champ</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="206"/>
        <source>Advanced options</source>
        <translation>Options avancées</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="218"/>
        <source>all pixels touch</source>
        <translation>Tous les pixels touchent</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="231"/>
        <source>buffer</source>
        <translation>Tampon</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="247"/>
        <source>0.00000</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="260"/>
        <source>meters</source>
        <translation>mètres</translation>
    </message>
</context>
<context>
    <name>osraster</name>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1031"/>
        <source>Save parameters File</source>
        <translation>Sauvegarde d&apos;un fichiers de paramètres</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1450"/>
        <source>Reset window ?</source>
        <translation>Réinitialiser la fenêtre ?</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="225"/>
        <source>
-&gt;NEW RASTER
</source>
        <translation>
-&gt;NOUVEAU RASTER
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="245"/>
        <source>
-&gt;NEW VECTOR
</source>
        <translation>
-&gt;NOUVEAU VECTEUR
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="267"/>
        <source>ERROR - File</source>
        <translation>ERREUR - Fichier</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="267"/>
        <source>This file is already loaded :
%s</source>
        <translation>Ce Fichier est déjà chargé :
%s</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="755"/>
        <source>ERROR - Nodata value</source>
        <translation>ERREUR - valeur nodata</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="755"/>
        <source>Fixed vector value can&apos;t be a nodata value.</source>
        <translation>Une valeur fixe de vecteur ne peut pas être une valeur de nodata.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="808"/>
        <source>ERROR - Incorrect code value</source>
        <translation>ERREUR - Valeur de code incorrecte</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="808"/>
        <source>Encoding code have to be an integer.</source>
        <translation>Un code d&apos;encodage doit être un entier.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="831"/>
        <source>

-&gt;VECTOR : %s
</source>
        <translation>

-&gt;VECTEUR : %s
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="835"/>
        <source>
-&gt;REPROJECTION VECTOR
</source>
        <translation>
-&gt;REPROJECTION VECTEUR
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="840"/>
        <source>
-&gt;BUFFERIZATION
</source>
        <translation>
-&gt;BUFFERISATION
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="863"/>
        <source>
-&gt;ADDING NEW ENCODING FROM STRING FIELD
</source>
        <translation>
-&gt;AJOUT NOUVEAU ENCODAGE DEPUIS UN CHAMP EN CHAINE DE CHARACTERES
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="923"/>
        <source>
-&gt;RASTERIZATION
</source>
        <translation>
-&gt;RASTERISATION
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="928"/>
        <source>
-&gt;SUBSTACTING CODE RASTER
</source>
        <translation type="obsolete">
-&gt;EXTRACTION CODES RASTER
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="972"/>
        <source>
-&gt;SEARCHING CODE TO REPLACE ON RASTER
</source>
        <translation>
-&gt;RECHERCHE DE CODES A REMPLACER DANS LE RASTER
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1000"/>
        <source>
-&gt;REPLACING CODE RASTER : %s
</source>
        <translation>
-&gt;REMPLACEMENT CODES RASTER : %s
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1066"/>
        <source>Open parameters File</source>
        <translation>Ouvrir un fichier de paramètres</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1169"/>
        <source>
-&gt;STARTING SPLITTING RASTER BY GROUP OF CODE
</source>
        <translation>
-&gt;COMMENCEMENT DE LA SEPARATION DE RASTERS PAR GROUPE DE CODES
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1251"/>
        <source>ERROR - resolution</source>
        <translation>ERREUR - Résolution</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1251"/>
        <source>Enter a correct resolution value.</source>
        <translation>Entrez une valeur de résolution correcte.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1273"/>
        <source>ERROR - extent</source>
        <translation>ERREUR - étendue</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1264"/>
        <source>Enter a correct extent values.</source>
        <translation>Entrez une valeur d&apos;étendue correcte.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1159"/>
        <source>The extent value can&apos;t be (0,0,0,0).</source>
        <translation type="obsolete">La valeur de l&apos;étendue ne peut pas être (0,0,0,0).</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1282"/>
        <source>There is no CRS selected.</source>
        <translation>Il n&apos;y a pas de SRC sélectionné.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1316"/>
        <source>-&gt;BEGINNING OF THE PROCESS

</source>
        <translation>-&gt;COMMENCEMENT DU PROCESSUS

</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1322"/>
        <source>
-&gt;SEARCHING FOR REPROJECTION ON RASTER
</source>
        <translation>
-&gt;RECHERCHE POUR LA PROJECTION DU RASTER
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1337"/>
        <source>
-&gt;REPROJECTION RASTER
</source>
        <translation>
-&gt;REPROJECTION RASTER
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1364"/>
        <source>
-&gt;MERGE
</source>
        <translation>
-&gt;FUSION
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1382"/>
        <source>Error: %s - %s.</source>
        <translation>Erreur: %s - %s.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1450"/>
        <source>Do you want to clear all the window ?</source>
        <translation>Voulez-vous effacer toute la fenêtre ?</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1234"/>
        <source>ERROR - merge</source>
        <translation>ERREUR - fusion</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1306"/>
        <source>ERROR - output</source>
        <translation>ERREUR - sortie</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1242"/>
        <source>The output tab isn&apos;t initialized.</source>
        <translation>L&apos;onglet de sortie n&apos;a pas été initialisé.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1234"/>
        <source>The merge tab isn&apos;t initialized.</source>
        <translation>L&apos;onglet de fusion n&apos;a pas été initialisé.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1292"/>
        <source>The nodata value is incorrect.</source>
        <translation>La valeur nodata est incorrecte.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="887"/>
        <source>
-&gt;COMMITTING CHANGES
</source>
        <translation>
-&gt;VALIDATION DES CHANGEMENTS
</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="740"/>
        <source>A code value can&apos;t be greater than 65 535.</source>
        <translation>Une valeur d&apos;encodage ne peut pas être supérieure à 65 535.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="734"/>
        <source>A code value can&apos;t be negative.</source>
        <translation>Une valeur d&apos;encodage ne peut pas être négative.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1299"/>
        <source>The nodata value can&apos;t be negative.</source>
        <translation>La valeur nodata ne peut pas être négative.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1306"/>
        <source>The nodata value can&apos;t be greater than 65 535.</source>
        <translation>La valeur nodata ne peut pas être supérieure à 65 535.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="174"/>
        <source>True</source>
        <translation>Vrai</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="174"/>
        <source>False</source>
        <translation>Faux</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="584"/>
        <source>Calculate from Layer</source>
        <translation>Calculer depuis une couche</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="1273"/>
        <source>The output can&apos;t have a size of 0 pixels.</source>
        <translation>La sortie ne peut pas avoir une taille de 0 pixel.</translation>
    </message>
    <message>
        <location filename="../OsRaster/OsRaster.py" line="940"/>
        <source>
-&gt;SUBTRACTING CODE RASTER
</source>
        <translation>
-&gt;EXTRACTION CODES RASTER
</translation>
    </message>
</context>
<context>
    <name>osraster_raster</name>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="166"/>
        <source>ERROR : Raster encoding value</source>
        <translation>ERREUR : Valeur encodage raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="166"/>
        <source>A code value set isn&apos;t valid.</source>
        <translation>Une valeur d&apos;encodage utilisée n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="180"/>
        <source>ERROR : Raster encoding size</source>
        <translation>ERREUR : Taille encodage raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="180"/>
        <source>A raster can&apos;t have 0 values.</source>
        <translation>Un raster ne peut pas avoir 0 valeurs.</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="199"/>
        <source>ERROR : Raster file value</source>
        <translation>ERREUR : Valeur fichier raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="199"/>
        <source>There is no file is set.</source>
        <translation>Il n&apos;y a pas de fichier chargé.</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="240"/>
        <source>ERROR : Raster file</source>
        <translation>ERREUR : Fichier raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="240"/>
        <source>The file isn&apos;t valid.</source>
        <translation>Le fichier n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="285"/>
        <source>ERROR : Raster unique codes</source>
        <translation>ERREUR : Codes uniques raster</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="285"/>
        <source>This raster has been ignored because there is too much unique code values. (MAX=%d)</source>
        <translation>Ce raster a été ignoré car il y a trop de valeurs de codes uniques. (MAX=%d)</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="144"/>
        <source>A code value can&apos;t be negative.</source>
        <translation>Une valeur d&apos;encodage ne peut pas être négative.</translation>
    </message>
    <message>
        <location filename="../OsRaster/raster_dialog.py" line="151"/>
        <source>A code value can&apos;t be greater than 65 535.</source>
        <translation>Une valeur d&apos;encodage ne peut pas être supérieure à 65 535.</translation>
    </message>
</context>
<context>
    <name>osraster_vector</name>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="127"/>
        <source>ERROR : Vector field value</source>
        <translation>ERREUR : Valeur champ vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="127"/>
        <source>The field value set isn&apos;t valid.</source>
        <translation>Le valeur du champ utilisé n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="168"/>
        <source>ERROR : Vector unique codes</source>
        <translation>ERREUR : Codes uniques vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="141"/>
        <source>Encoding can&apos;t use float value if they can&apos;t represent an integer.</source>
        <translation>L&apos;encodage ne peut pas utiliser des valeurs flottantes si elles ne peuvent pas représenter un entier.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="168"/>
        <source>There is too much unique code values. (MAX=%d)</source>
        <translation>Il y a trop de valeurs de codes uniques. (MAX=%d)</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="200"/>
        <source>ERROR : Vector burn-in value</source>
        <translation>ERREUR : Valeur rodage vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="184"/>
        <source>The burn-in value set isn&apos;t valid.</source>
        <translation>La valeur de rodage utilisée n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="232"/>
        <source>ERROR : Vector encoding size</source>
        <translation>ERREUR : Taille encodage vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="232"/>
        <source>A vector can&apos;t have 0 values.</source>
        <translation>Un vecteur ne peut pas avoir 0 valeurs.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="254"/>
        <source>ERROR : Vector file value</source>
        <translation>ERREUR : Valeur fichier vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="254"/>
        <source>There is no file is set.</source>
        <translation>Il n&apos;y a pas de fichier chargé.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="312"/>
        <source>ERROR : Vector file</source>
        <translation>ERREUR : Fichier vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="312"/>
        <source>The file isn&apos;t valid.</source>
        <translation>Le fichier n&apos;est pas valide.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="219"/>
        <source>ERROR : Vector buffer value</source>
        <translation>ERREUR : Valeur buffer vecteur</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="219"/>
        <source>A buffer value have to be a numeric greater than 0.</source>
        <translation>Une valeur de buffer doit être une valeur numérique supérieure à 0.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="192"/>
        <source>The burn-in value can&apos;t be negative.</source>
        <translation>La valeur de rodage ne peut pas être une valeur négative.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="152"/>
        <source>A code value can&apos;t be negative.</source>
        <translation>Une valeur d&apos;encodage ne peut pas être négative.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="160"/>
        <source>A code value can&apos;t be greater than 65 535.</source>
        <translation>Une valeur d&apos;encodage ne peut pas être supérieure à 65 535.</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="160"/>
        <source>ERROR : Vector encoding value</source>
        <translation>ERREUR : Valeur d&apos;encodage vector</translation>
    </message>
    <message>
        <location filename="../OsRaster/vector_dialog.py" line="200"/>
        <source>The burn-in value can&apos;t be greater than 65 535.</source>
        <translation>La valeur de rodage ne peut pas être supérieure à 65 353.</translation>
    </message>
</context>
<context>
    <name>py</name>
    <message>
        <location filename="../processing/CalculateLocalMetric.py" line="216"/>
        <source>Calculate Local Metric</source>
        <translation>Métrique locale</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="73"/>
        <source>Project name</source>
        <translation>Nom du projet</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="83"/>
        <source>Landscape raster</source>
        <translation>Carte du paysage</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="92"/>
        <source>Habitat patch codes (separated by commas ex: 1,4,3)</source>
        <translation>Codes d&apos;habitat (séparé par des virgules ex: 1,4,3)</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="101"/>
        <source>Project destination folder</source>
        <translation>Répertoire de création du projet</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="207"/>
        <source>Create Project</source>
        <translation>Créer un projet</translation>
    </message>
    <message>
        <location filename="../processing/CreateLinkset.py" line="71"/>
        <source>XML project file</source>
        <translation>Fichier XML du projet</translation>
    </message>
    <message>
        <location filename="../processing/CreateGraph.py" line="89"/>
        <source>Graph name</source>
        <translation>Nom du Graphe</translation>
    </message>
    <message>
        <location filename="../processing/CalculateGlobalMetric.py" line="93"/>
        <source>Global metric</source>
        <translation>Métrique globale</translation>
    </message>
    <message>
        <location filename="../processing/CalculateLocalMetric.py" line="115"/>
        <source>Distance</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../processing/CalculateLocalMetric.py" line="127"/>
        <source>Probability</source>
        <translation>Probabilité</translation>
    </message>
    <message>
        <location filename="../processing/CalculateLocalMetric.py" line="92"/>
        <source>Local metric</source>
        <translation>Métrique locale</translation>
    </message>
    <message>
        <location filename="../processing/CreateLinkset.py" line="80"/>
        <source>Linkset name</source>
        <translation>Nom du jeu de liens</translation>
    </message>
    <message>
        <location filename="../processing/CreateGraph.py" line="111"/>
        <source>Threshold distance for pruning (0 = no pruning)</source>
        <translation>Seuil de distance pour l&apos;élagage (0 = pas d&apos;élagage)</translation>
    </message>
    <message>
        <location filename="../processing/CreateGraph.py" line="181"/>
        <source>Create Graph</source>
        <translation>Créer un Graphe</translation>
    </message>
    <message>
        <location filename="../processing/CreateLinkset.py" line="90"/>
        <source>Distance type</source>
        <translation>Type de distance</translation>
    </message>
    <message>
        <location filename="../processing/CreateLinkset.py" line="110"/>
        <source>External cost raster</source>
        <translation>Raster de coût externe</translation>
    </message>
    <message>
        <location filename="../processing/CreateLinkset.py" line="179"/>
        <source>Create Linkset</source>
        <translation>Créer un jeu de liens</translation>
    </message>
    <message>
        <location filename="../processing/CalculateGlobalMetric.py" line="138"/>
        <source>Global Metric value</source>
        <translation>Valeur de la métrique globale</translation>
    </message>
    <message>
        <location filename="../processing/CalculateGlobalMetric.py" line="200"/>
        <source>Calculate Global Metric</source>
        <translation>Métrique globale</translation>
    </message>
    <message>
        <location filename="../OsRaster/ui_files/OsRaster_option_vector_window.ui" line="292"/>
        <source>Distance (in meter) :</source>
        <translation type="obsolete">Distance (en mètre) :</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="218"/>
        <source>Load a project</source>
        <translation>Charger un projet</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="245"/>
        <source>Remove Linkset</source>
        <translation>Supprimer un jeu de liens</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="257"/>
        <source>Remove Graph</source>
        <translation>Supprimer un graphe</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="345"/>
        <source>Remove linkset</source>
        <translation>Supprimer un jeu de liens</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="339"/>
        <source>Select the linkset to remove :</source>
        <translation>Sélectionner le jeu de liens à supprimer :</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="365"/>
        <source>Remove graph</source>
        <translation>Supprimer un graphe</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="359"/>
        <source>Select the graph to remove :</source>
        <translation>sélectionner le graphe à supprimer :</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="282"/>
        <source>Display metric</source>
        <translation>Afficher une métrique</translation>
    </message>
    <message>
        <location filename="../processing/CreateLinkset.py" line="100"/>
        <source>Costs definition from landscape codes (ex: 1,2=1 3,4,5=10 6,7=100)</source>
        <translation>Définition des coûts à partir de la carte de paysage (ex: 1,2=1 3,4,5=10 6,7=100)</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="103"/>
        <source>Meter</source>
        <translation>Mètre</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="103"/>
        <source>Cost</source>
        <translation>Coût</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="263"/>
        <source>Calculate Corridors</source>
        <translation>Corridors</translation>
    </message>
    <message>
        <location filename="../processing/CreateGraph.py" line="98"/>
        <source>Distance unit</source>
        <translation>Unité de distance</translation>
    </message>
    <message>
        <location filename="../processing/CalculateCorridor.py" line="98"/>
        <source>Maximum distance</source>
        <translation>Distance maximum</translation>
    </message>
    <message>
        <location filename="../processing/CalculateCorridor.py" line="167"/>
        <source>Create corridors</source>
        <translation>Corridors</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="110"/>
        <source>Minimum size patches (hectare)</source>
        <translation>Taille minimale des taches (hectare)</translation>
    </message>
    <message>
        <location filename="../GraphabPlugin.py" line="225"/>
        <source>Create landscape map</source>
        <translation>Créer une carte d&apos;occupation du sol</translation>
    </message>
    <message>
        <location filename="../processing/CreateProject.py" line="122"/>
        <source>Nodata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../processing/GraphabProvider.py" line="45"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../processing/GraphabProvider.py" line="47"/>
        <source>Max memory for Java in Gb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../processing/GraphabProvider.py" line="49"/>
        <source>Processors/Cores used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../processing/GraphabProvider.py" line="51"/>
        <source>Java path executable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
