
__author__ = 'gaspard.quentin1905@gmail.com'
__date__ = '2023-06-23'
__copyright__ = 'Copyright 2023, Laboratoire ThéMA'

import unittest
import os.path
import pathlib

from qgis.core import QgsVectorLayer

class GraphabTestCase(unittest.TestCase):
    def setUp(self):
        print(f"------[Starting {self.__class__.__name__}------]")
        self.vector_layer = QgsVectorLayer(os.path.join(pathlib.Path(__file__).parent.resolve()))

    def tearDown(self):
        print(f"------[End {self.__class__.__name__}]------")


