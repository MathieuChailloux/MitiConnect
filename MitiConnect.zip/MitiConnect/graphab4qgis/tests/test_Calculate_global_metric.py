
__author__ = 'gaspard.quentin1905@gmail.com'
__date__ = '2023-06-26'
__copyright__ = 'Copyright 2023, Laboratoire ThéMA'

import unittest

from .graphab_test_case import GraphabTestCase
from ..processing.CalculateGlobalMetric import CalculateGlobalMetric
from qgis.core import QgsProcessingContext, QgsProcessingFeedback

class TestCalculateGlobalMetric(GraphabTestCase):

    @unittest.skip('Test not implemented yet.')
    def test_processing_algo(self) -> None:

        # TODO: test with relevant config parameters
        config = {
            'INPUT': None, # xml file that represent the Graphab Project
            'GRAPHNAME': '',
            'METRICSNAME': 0,
            'DPARAMETER': 1000.0,
            'PPARAMETER': 0,
            'DISTUNIT': 0
        }

        # init algo, context & feedback
        alg = CalculateGlobalMetric()
        ctx = QgsProcessingContext()
        feedback = QgsProcessingFeedback()

        alg.initAlgorithm(config)

        # processing algo and get output
        output: dict[str, any] = alg.processAlgorithm(config, ctx, feedback)

        # tests on the output
        # TODO: make relevant tests
        self.assertIsNotNone(output)

if __name__ == '__main__':
    suite: unittest.TestSuite = unittest.makeSuite(TestCalculateGlobalMetric)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)