pylupdate5 -verbose ../*.py ../processing/*.py ../OsRaster/*.py ../ui_files/*.ui ../OsRaster/ui_files/*.ui -ts fr.ts

