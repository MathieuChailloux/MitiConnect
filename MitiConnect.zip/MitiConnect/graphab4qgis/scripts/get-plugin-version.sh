#!/bin/sh

VERSION=$(awk -F "=" '/version/ {print $2}' metadata.txt)
echo $VERSION