
__author__ = 'gaspard.quentin1905@gmail.com'
__date__ = '2023-06-26'
__copyright__ = 'Copyright 2023, Laboratoire ThéMA'

import unittest

from .graphab_test_case import GraphabTestCase
from ..processing.CalculateCorridor import CalculateCorridor
from qgis.core import QgsProcessingFeedback, QgsProcessingContext

class TestCalculateCorridor(GraphabTestCase):

    @unittest.skip("Test not implemented yet.")
    def test_processing_algo(self) -> None:

        # TODO: test with relevant config parameters
        config = {
            'INPUT': None, # replace with XML file representing a Graphab project 
            'NAMELINKSET': None,
            'DIST': 0.0,
            'DISTUNIT': 0
        }

        # init algo, context & feedback
        alg = CalculateCorridor()
        ctx = QgsProcessingContext()
        feedback = QgsProcessingFeedback()

        alg.initAlgorithm(config)

        # process algo and get output
        output: dict[str, any] = alg.processAlgorithm(config, ctx, feedback)

        # post process
        alg.postProcessAlgorithm(ctx, feedback)

        # tests on the output
        # TODO: make relevant tests
        self.assertIsNotNone(output)

if __name__ == '__main__':
    suite = unittest.makeSuite(TestCalculateCorridor)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)